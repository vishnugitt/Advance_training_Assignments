package program24;

import java.util.Scanner;

public class StringShuffle {
	
	public static boolean isInterleaving(String first, String second, String third)
	{
		
		if (first.length() == 0 && second.length() == 0 && third.length() == 0) {
			return true;
		}

		if (third.length() == 0) {
			return false;
		}


		boolean x = (first.length() != 0 && third.charAt(0) == first.charAt(0)) &&
				isInterleaving(first.substring(1), second, third.substring(1));


		boolean y = (second.length() != 0 && third.charAt(0) == second.charAt(0)) &&
				isInterleaving(first, second.substring(1), third.substring(1));

		return x || y;
	}

	public static void main(String[] args)
	{
		
		
		Scanner S=new Scanner(System.in);
		System.out.println("Enter The First String :");
		String X=S.nextLine();
		System.out.println("Enter The Second String :");
		String Y=S.nextLine();
		System.out.println("Enter The Third String :");
		String Z=S.nextLine();		
		

		if (isInterleaving(X, Y, Z)) {
			System.out.print("true:third string is valid shuffle of first and second string");
		}
		else {
			System.out.print("false:third string is not a valid shuffle of first and second string");
		}
	}
}