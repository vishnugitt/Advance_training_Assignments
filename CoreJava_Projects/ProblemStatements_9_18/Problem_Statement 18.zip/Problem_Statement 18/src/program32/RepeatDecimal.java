package program32;

import java.util.*;

public class RepeatDecimal
{

	public static String calculateFraction(int numerator, int denominator)
	{
		if (numerator == 0)
			return "0"; 
		if (denominator == 0)
			return ""; 

		

		StringBuilder result = new StringBuilder();
		if ((numerator < 0) ^ (denominator < 0))
			result.append("-");

		numerator = Math.abs(numerator);
		denominator = Math.abs(denominator);

		long quo = numerator / denominator; 
		long rem = numerator % denominator * 10; 

		result.append(
			String.valueOf(quo));
		if (rem == 0)
			return result
				.toString(); 

		result.append(".");
		Map<Long, Integer> m
			= new HashMap<>(); 
		while (rem != 0) 
		{

			if (m.containsKey(rem)) 
			{

				int index = m.get(rem);
				String part1 = result.substring(0, index);
				String part2 = "("
							+ result.substring(
								index, result.length())
							+ ")";
				return part1 + part2;
			}

			

			m.put(rem, result.length());
			quo = rem / denominator;
			result.append(String.valueOf(quo));

			
			rem = (rem % denominator) * 10;
			
		}
		return result.toString();
	}

	
	public static void main(String[] args)
	{
		int numerator = 1;
		int denominator = 3;
		

		String resString1 = calculateFraction(numerator, denominator);

		numerator = 1;
		denominator = 4;

		String resString2 = calculateFraction(numerator, denominator);
		
		numerator = 1;
		denominator = 6;

		String resString3 = calculateFraction(numerator, denominator);
		
		numerator = 1;
		denominator = 7;

		String resString4 = calculateFraction(numerator, denominator);

		System.out.println(resString1);
		System.out.println(resString2);
		System.out.println(resString3);
		System.out.println(resString4);
	}
}
