package program16;

public class Employee 
{
	 private int empnum;
	 private String empname, address;
	 public Employee (int empnum, String empname, String address)
	 {
		 super();
		 this.empnum=empnum;
		 this.empname=empname;
		 this.address=address;
		 }
	 public int getEmpnum() 
	 {
		 return empnum;
	 }
	 public void setEmpnum(int empnum)
	 {
		 this.empnum=empnum;
	 }
	 public String getEmpname()
	 {
		 return empname;
	 }
	 public void setEmpname(String empname) 
	 {
		 this.empname=empname;
	 }
	 public String getAddress()
	 {
		 return address;
	 }
	 public void setAddres(String address)
	 {
		 this.address=address;
	 }
	}