package program9;

public class Medicines 
{

public void displayLabel()
{
	System.out.println("Company : Apollo Pharma");
	System.out.println("Address : Bangalore");
	}
}
class Tablets extends Medicines
{
	 
public void displayLabel()
{
	System.out.println("store in a cool dry place");
	}
}
class Syrup extends Medicines
{
	public void displayLabel()
	{
		System.out.println("Consumption as directed by the physician");
		}
	}
class Ointment extends Medicines
{
	public void displayLabel(){
		System.out.println("for external use only");
		}
	}