package program11;

public class Manipulate_String {

	public static void main(String[] args) {
		
	
	String str= "JAVA is Simple";
	
	System.out.println(str.toUpperCase()); //UpperCase
	
	System.out.println(str.toLowerCase()); //LowerCase
	
	
	String[] words=str.split("\\s");	//1st words of letter
	for(String w:words){  
		System.out.print(w.charAt(0)); 
		System.out.print(" ");
	}
	System.out.println(" ");
	
	
	String[] words1=str.split("\\s"); // Change order 
	for(String w:words1){  
		//System.out.println(w); 
	}
	
	//String Builder reverse
	StringBuilder words2= new StringBuilder("Simple is JAVA");
	
	Object words21;
	System.out.println("String = " + words2.toString());
	StringBuilder reverseStr = words2.reverse();
	System.out.println("Reverse String = " + reverseStr.toString());
	
	//Total Length
	System.out.println("length of string " +str.length());
}
}