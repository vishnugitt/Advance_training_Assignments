package program6;

public class TwoNumbers {

	  public static void main(String[] args) {

	    int i = 1, n = 13, number1 = 0, number2 = 1;
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(number1 + ", ");

	      int number3 = number1 + number2;
	      number1 = number2;
	      number2 = number3;

	      i++;
	    }
	  }
	}