package com.org.myapp.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.org.myapp.dao.Dao;
import com.org.myapp.dao.EbookDao;
import com.org.myapp.dbutil.DbUtil;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private  EbookDao DAO;
	
	@Override
	public void init() throws ServletException {
		super.init();
		
		ServletContext ctx = this.getServletContext();
	    DbUtil dbUtil = (DbUtil) ctx.getAttribute("db");
	    DAO = new EbookDao(dbUtil);

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		if(session.getAttribute("userid") != null) {
			
			session.invalidate();
			response.sendRedirect("./Home.jsp");
			return;
		}
		response.sendRedirect("./login");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
     
}
